rm(list=ls())
### Pacotes
sapply(c("sp", "maptools", "spdep", "rgdal"), require, char=T)

### Shapefile de Curitiba com divisão por bairros
#download.file('http://ippuc.org.br/geodownloads/SHAPES/DIVISA_DE_BAIRROS.zip'
              ,destfile='DIVISA_DE_BAIRROS.zip')
#unzip('DIVISA_DE_BAIRROS.zip')

### Shapefile do Paraná por setores censitários
#download.file("ftp://geoftp.ibge.gov.br/organizacao_do_territorio/malhas_territoriais/malhas_de_setores_censitarios__divisoes_intramunicipais/censo_2010/setores_censitarios_shp/pr/pr_setores_censitarios.zip",destfile="pr_setores_censitarios.zip")

### Shapefile de Curitiba por setores censitários
#download.file('http://www.leg.ufpr.br/lib/exe/fetch.php/pessoais:curitiba.zip',destfile='curitiba.zip')

##### lendo o mapa de Curitiba por bairro
bairro<-readOGR("DIVISA_DE_BAIRROS.shp" ,layer='DIVISA_DE_BAIRROS')

##### lendo o mapa do estado de Curitiba por setor censitário
cwb<-readOGR("4106902.shp",layer="4106902")

### Plotando os mapas do Bairro de Santa Felicidade e dos setores censitários
plot(bairro[bairro$NOME=='SANTA FELICIDADE',],
     border='gray10', lwd=2, cex.main=0.85,
     main='')

#setwd('~/Documentos/Consultoria/Isabel/Isabel')
options("scipen"=100, "digits"=10)
### Criando os códigos dos setores censitários
code <-as.numeric(paste0(410690205050,141:180))
code
### Plotando os setores censitários
for(i in 1:length(code))
    plot(cwb[cwb$ID_==code[i],],
     border='gray10', lwd=1, add=T)

#============================================================================
#============ CADASTRO DE ENDEREÇOS PARA FINS ESTATÍSTICOS===================
#============================================================================
#=============== http://www.censo2010.ibge.gov.br/cnefe/ ====================
#============================================================================

#setwd("/home/felipe/Documentos/Consultoria/Isabel/Curitiba")
dir(pattern='.csv')   # lista todos os arquivos com extensão .csv
input <- dir(pattern='.csv')
L <- length(input)

### Renomeando os termos da lista
dados <- list(setor10=input[1],setor11=input[2],setor12=input[3],
              setor13=input[4],setor14=input[5],setor15=input[6],
              setor16=input[7],setor17=input[8],setor18=input[9],
              setor19=input[10],setor1=input[11],setor20=input[12],
              setor21=input[13],setor22=input[14],setor23=input[15],
              setor24=input[16],setor25=input[17],setor26=input[18],
              setor27=input[19],setor28=input[20],setor29=input[21],
              setor2=input[22],setor30=input[23],setor31=input[24],
              setor32=input[25],setor33=input[26],setor34=input[27],
              setor35=input[28],setor36=input[29],setor37=input[30],
              setor38=input[31],setor3=input[32],setor4=input[33],
              setor5=input[34],setor6=input[35],setor7=input[36],
              setor8=input[37],setor9=input[38])

### Lendo arquivos com endereços
for (i in 1:L){
    dados[[i]] <- read.csv(input[i],h=T,sep=',')
    cat(input[i],'\n')
}

#### Calculando o tamanho de cada setor censitário
N <- NULL
for (i in 1:L)
    N <- c(N,nrow(dados[[i]]))
N
#### Calculando o tamanho da população
sum(N)

options("scipen"=-100, "digits"=10)
#### Definindo uma amostra
set.seed(19991239)
dados.df <- plyr::rbind.fill(dados)
amostra <-dados.df[sample(nrow(dados.df), 800), ]
dim(amostra)
amostra_geo <- amostra[,c(3,4)]
names(amostra_geo)

### preparando endereços
end <- paste(amostra_geo$Logradouro, amostra_geo$Número.no.logradouro
           , '-',  'Curitiba', 'Brasil', sep=',+')
end <- gsub(' ', '+', end, fixed=TRUE)
end <- gsub('NA,+', '', end, fixed=TRUE)

### obtem longitude,latitude coordenadas
#require(ggmap)
result <- t(sapply(end, ggmap::geocode))
res <- as.data.frame(result)

##### lendo o mapa do PR por setor censitário
PR <- readOGR('.',layer='41SEE250GC_SIR')

##### Separando shape de Curitiba
CTBA <- PR[PR$NM_MUNICIP=='CURITIBA',]

##### Plotando os setores cesnsitários
plot(CTBA[CTBA$CD_GEOCODI==code[1],], xlim=c(-49.359338642,-49.27522500),
     ylim=c(-25.43538622, -25.35673603))
for (i in 2:length(code))
    plot(CTBA[CTBA$CD_GEOCODI==code[i],],add=T, cex.points=.3)

##### Indicando a posição dos domicílios
points(res$lon,res$lat,pch=1, col='darkgreen',cex=.3)

