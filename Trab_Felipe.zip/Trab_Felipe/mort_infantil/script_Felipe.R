#=================================================================================================================================
# R PROGRAM TO READ DATA FROM SIM AND SINASC TO INFANT MORTALITY IN CURITBRA - BRAZIL
# Copyright (C) 2016 FELIPE BARLETTA - email: felipe.barletta@hotmail.com - url: http://www.leg.ufpr.br/doku.php/pessoais:felipe
#=================================================================================================================================

#=================================================================================================================================
# This function allows you load data from SIM and SINASC (DATASUS - Brazilian
# Ministry of Health) to read a DBC (compressed DBF) file into a data frame.
# DBC is the extension for compressed DBF files.
# DATASUS is the name of the Department of Informatics of the Brazilian Health System and
# is resposible for publishing public healthcare data.
#=================================================================================================================================

#=================================================================================================================================
# This function and software are free: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation
# R Core Team (2016). R: A language and environment for statistical
# computing. R Foundation for Statistical Computing, Vienna, Austria.
# URL https://www.R-project.org/
#=================================================================================================================================

#=================================================================================================================================
# Package: IT IS NOT A PACKAGE, ONLY A PROGRAM - VERSION: 1.0
# Date: 2016-07-15
# Title: Data for Infant Mortality Analysis
# Author: Felipe Barletta <felipe.barletta@hotmail.com>
# Maintainer: Felipe Barletta <felipe.barletta@hotmail.com>
# Depends: R (>= 3.10), stats, methods
# Imports: plyr, date, foreign
# Suggests: scatterplot3d, lattice, tcltk, geoRglm
# Description: Download data from sim and sinasc to infant mortality in Curitiba-Brazil
# URL: http://www.leg.ufpr.br/geoR
# Built: R version 3.2.5; x86_64-pc-linux-gnu
#=================================================================================================================================


#=================================================================================================================================
# Website SIM: <http://tabnet.datasus.gov.br/cgi/sim/dados/indice.htm>
# Website SINASC: <http://tabnet.datasus.gov.br/cgi/sinasc/dados/indice.htm>
#=================================================================================================================================

rm(list=ls())
#setwd('~/Documentos/PBE/dados_epi/trab_final/mort_infantil')
#getwd()

#========================================= SIM ===================================================================================

#========================================= PART I ================================================================================
#================== RUN IF IS THE FIRTS TIME THAT YOU WILL DOWNLOAD THE SIM INFORMATION ==========================================
#================== IF NOT GO TO SECOND PART PROGRAM =============================================================================
#=================================================================================================================================

### vector with the desired years
year <-c(paste0(0,4:9),paste0(1,0:4))

### Loop to download mortality information from SIM and to uncompress dbc databse by TABWIN program
arq_dbc<-NULL
for(i in year){
  arq_dbc <- c(arq_dbc,paste('DOINF',i,'.dbc',sep=''))
  for (j in length(arq_dbc)){
    download.file(paste0('ftp://ftp.datasus.gov.br/dissemin/publicos/SIM/CID10/DOFET/',arq_dbc[j]),paste0(arq_dbc[j]))
    system(paste('wine /home/felipe/dbf2dbc.exe', arq_dbc[j]))
  }
}

### Loop to  read dbf database for all years
dados <- NULL
for (k in 1:length(arq_dbc))
    dados[[k]] <- foreign::read.dbf(gsub('dbc','dbf',arq_dbc[k]))

#tamanho <-NULL
#for (l in 1:length(arq_dbc))
#    tamanho <- rbind(tamanho,(dim(dados[[l]])))
#tamanho

### Creating vector with the objects names from list
dados.df <- lapply(ls(pattern='dados'), get)
### Load package to splitting, applying and combining data
require(plyr)
### Transforming a list objetc to data.frame object
dados.df2 <- do.call('rbind.fill',dados.df)

### Selecting variables
var.sel <- c('DTOBITO','DTNASC', 'SEXO','RACACOR','ESTCIV','IDADEMAE','PESO',
             'ESCMAE','QTDFILVIVO','QTDFILMORT','GRAVIDEZ','GESTACAO','PARTO',
             'CODMUNRES')
dados.final <- dados.df2[,c(var.sel)]

### Creating age variable by days
dados.final$IDADE_DIAS<- date::as.date(as.character(dados.final$DTOBITO),order='dmy') -
       date::as.date(as.character(dados.final$DTNASC),order='dmy')

### Selecting records about infant mortality and Curitiba city
infant_mortality_CTBA <- subset(dados.final,  IDADE_DIAS>=1 & IDADE_DIAS<=365 &  CODMUNRES=='4106902')

### Creating one level to dependent variable
infant_mortality_CTBA$Y <- factor(rep(1,length(infant_mortality_CTBA[,1])))

### Saving data to .RData format
save(infant_mortality_CTBA, file='infant_mortality_CTBA_R.RData')

#========================================= PART II ===============================================================================
#================== RUN IF YOU WANT TO ADD ONLY ONE YEARS ========================================================================
#=================================================================================================================================
rm(list=ls())

### Add the year with the two last digits (Where is YY - put the year)
new_year <- 'DOINF04.dbc'

download.file(paste0('ftp://ftp.datasus.gov.br/dissemin/publicos/SIM/CID10/DOFET/',new_year),paste0(new_year))
system(paste('wine /home/felipe/dbf2dbc.exe', new_year))

dados <- foreign::read.dbf(gsub('dbc','dbf',new_year))

### Selecting variables
var.sel <- c('DTOBITO','DTNASC', 'SEXO','RACACOR','ESTCIV','IDADEMAE','PESO',
             'ESCMAE','QTDFILVIVO','QTDFILMORT','GRAVIDEZ','GESTACAO','PARTO',
             'CODMUNRES')
dados.final <- dados[,c(var.sel)]

### Creating age variable by days
dados.final$IDADE_DIAS<- date::as.date(as.character(dados.final$DTOBITO),order='dmy') -
       date::as.date(as.character(dados.final$DTNASC),order='dmy')

### Selecting records about infant mortality and Curitiba city
infant_mortality_CTBA2 <- subset(dados.final,  IDADE_DIAS>=1 & IDADE_DIAS<=365 &  CODMUNRES=='4106902')

### Creating one level to dependent variable
infant_mortality_CTBA2$Y <- factor(rep(1,length(infant_mortality_CTBA2[,1])))

### Loading old records
load('infant_mortality_CTBA_R.RData')

### joining the datas
infant_mortality_CTBA <- plyr::rbind.fill(infant_mortality_CTBA,infant_mortality_CTBA2)

### Saving data to .RData format
save(infant_mortality_CTBA, file='infant_mortality_CTBA_R.RData')

#========================================= SINASC ===================================================================================

#========================================= PART I ================================================================================
#================== RUN IF IS THE FIRTS TIME THAT YOU WILL DOWNLOAD THE SINASC INFORMATION =======================================
#================== IF NOT GO TO SECOND PART PROGRAM =============================================================================
#=================================================================================================================================
rm(list=ls())

### vector with the desired years
year <-c(paste0(200,4:9),paste0(201,0:4))
year
### Loop to download mortality information from SIM and to uncompress dbc databse by TABWIN program
arq_dbc<-NULL
for(i in year){
  arq_dbc <- c(arq_dbc,paste('DNPR',i,'.dbc',sep=''))
  for (j in length(arq_dbc)){
    download.file(paste0('ftp://ftp.datasus.gov.br/dissemin/publicos/SINASC/NOV/DNRES//',arq_dbc[j]),paste0(arq_dbc[j]))
    system(paste('wine /home/felipe/dbf2dbc.exe', arq_dbc[j]))
  }
}

### Loop to  read dbf database for all years
dados <- NULL
for (k in 1:length(arq_dbc))
    dados[[k]] <- foreign::read.dbf(gsub('dbc','dbf',arq_dbc[k]))

tamanho <-NULL
for (l in 1:length(arq_dbc))
    tamanho <- rbind(tamanho,(dim(dados[[l]])))
tamanho
names(dados[[1]])

### Creating vector with the objects names from list
dados.df <- lapply(ls(pattern='dados'), get)
### Load package to splitting, applying and combining data
require(plyr)
### Transforming a list objetc to data.frame object
dados.df2 <- do.call('rbind.fill',dados.df)

### Renaming the a variable
dados.df2$ESTCIV <- dados.df2$ESTCIVMAE

### Selecting variables
var.sel <- c('DTNASC', 'SEXO','RACACOR','ESTCIV','IDADEMAE','PESO',
             'ESCMAE','QTDFILVIVO','QTDFILMORT','GRAVIDEZ','GESTACAO','PARTO',
             'CODMUNRES')

dados.final <- dados.df2[,c(var.sel)]

### Creating variable year
dados.final$NASC_YYYY<- substr(dados.final$DTNASC, start=5, stop=8)


### Selecting records about infant mortality and Curitiba city
SINASC_CTBA <- subset(dados.final,  CODMUNRES=='4106902')

### Creating one level to dependent variable
SINASC_CTBA$Y <- factor(rep(0,length(SINASC_CTBA[,1])))

### Saving data to .RData format
save(SINASC_CTBA, file='SINASC_CTBA_R.RData')


#========================================= PART II ===============================================================================
#================== RUN IF YOU WANT TO ADD ONLY ONE YEARS ========================================================================
#=================================================================================================================================
rm(list=ls())

### Add the year with the four last digits (Where is YYYY - put the year)l
new_year <- 'DNPR2004.dbc'

download.file(paste0('ftp://ftp.datasus.gov.br/dissemin/publicos/SINASC/NOV/DNRES//',new_year),paste0(new_year))
system(paste('wine /home/felipe/dbf2dbc.exe', new_year))

dados <- foreign::read.dbf(gsub('dbc','dbf',new_year))

### Renaming the a variable
dados$ESTCIV <- dados$ESTCIVMAE

### Selecting variables
var.sel <- c('DTNASC', 'SEXO','RACACOR','ESTCIV','IDADEMAE','PESO',
             'ESCMAE','QTDFILVIVO','QTDFILMORT','GRAVIDEZ','GESTACAO','PARTO',
             'CODMUNRES')
dados.final <- dados[,c(var.sel)]

### Creating  variable year
dados.final$NASC_YYYY<- substr(dados.final$DTNASC, start=5, stop=8)

### Selecting records about infant mortality and Curitiba city
SINASC_CTBA2 <- subset(dados.final,  CODMUNRES=='4106902' & NASC_YYYY=='2004')

### Creating one level to dependent variable
SINASC_CTBA2$Y <- factor(rep(0,length(SINASC_CTBA2[,1])))


### Loading old records
load('SINASC_CTBA_R.RData')

### joining the datas
SINASC_CTBA_ATUAL <- plyr::rbind.fill(SINASC_CTBA,SINASC_CTBA2)

### Saving data to .RData format
save(SINASC_CTBA_ATUAL, file='SINASC_CTBA_R.RData')

load('SINASC_CTBA_R.RData')

#=================================================================================================================================
#===================================== SAMPLE =====================================================================================
#=================================================================================================================================

### Selecting SINASC sample
load('infant_mortality_CTBA_R.RData')
n <- 2*nrow(infant_mortality_CTBA)
set.seed(19991239)
SINASC_sample <-SINASC_CTBA_ATUAL[sample(nrow(SINASC_CTBA_ATUAL), n), ]

### FINAL SAMPLE
final_sample <- plyr::rbind.fill(SINASC_sample,infant_mortality_CTBA)
summary(final_sample$Y)


#=================================================================================================================================
#===================================== MODELS ====================================================================================
#=================================================================================================================================


### DECISION TREE

### LOGISTIC REGRESSION

### GENERALIZED ADITTIVE MODEL




#=================================================================================================================================
#===================================== GEOREFERENCE ==============================================================================
#=================================================================================================================================
#install.packages('ggmap',repos='http://cran-r.c3sl.ufpr.br/')
### Exemplo: Meu endereço em Curitiba
ggmap::geocode('Rua+Tamoios,+955+-+Curitiba+PR+Brasil')

### Exemplo: Meu endereço em Maringa
ggmap::geocode('Rua+Bragança,+43+-+Maringá+PR+Brasil')

## Vários endereços num 'data.frame', é preciso collapsar os campos.
## Exemplo:
dados <- data.frame(tipo = c('av', 'rua', NA,'CEP'),
                    nome = c('Silva Jardim', 'Alagoas', 'prefeitura', '80060-000'),
                    num = c(3100, 100, NA, NA),
                    cidade = rep('Curitiba', 4))

### preparando endereços
lograd <- paste(dados$tipo, dados$nome, dados$num, '-', dados$cidade, 'Brasil', sep=',+')
lograd <- gsub(' ', '+', lograd, fixed=TRUE)
lograd <- gsub('NA,+', '', lograd, fixed=TRUE)
lograd
### obtem longitude,latitude coordenadas
resultado <- t(sapply(lograd, ggmap::geocode))
resultado

